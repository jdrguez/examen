import { defineStore } from 'pinia';

export const useBlogStore = defineStore('blog', {
  state: () => ({
    posts: []
  }),
  actions: {
    createPost(post) {
      this.posts.push({ id: Math.floor(Math.random() * (150 - 0) + 0), ...post });
    },
    updatePost(id, updatedPost) {
      const index = this.posts.findIndex(post => post.id === id);
      if (index !== -1) {
        this.posts[index] = { ...this.posts[index], ...updatedPost };
      }
    },
    getPostById(id) {
      const post = this.posts.find(post => post.id === id);
      return post;
    }
  }
});
