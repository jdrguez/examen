declare module './router.js' {
  import { Router } from 'vue-router';
  const router: Router;
  export default router;
}
