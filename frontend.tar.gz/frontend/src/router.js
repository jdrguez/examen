import { createRouter, createWebHistory } from "vue-router"

import About from "./components/About.vue"
import Contact from "./components/Contact.vue"
import Skills from "./components/Skills.vue"
import Experience from "./components/Experience.vue"
import Error404 from "./components/Error404.vue"
import Projects from "./components/Projects.vue"
import LoginView from './views/LoginView.vue'
import RegisterView from './views/RegisterView.vue'
import BlogForm from './components/BlogForm.vue'
import BlogList from './components/BlogList.vue'
import BlogPost from './components/BlogPost.vue'

const routes = [
    {path: "/", redirect:'/login'},
    {path: "/about", component: About},
    {path: "/projects", component: Projects},
    {path: "/contact", component: Contact},
    {path: "/skills", component: Skills},
    {path: "/experiences", component: Experience},
    {
        path: '/login',
        name: 'LoginView',
        component: LoginView,
      },
      {
        path: '/register',
        name: 'RegisterView',
        component: RegisterView,
    
      },
      {
        path: '/blog',
        component: BlogList
      },
      {
        path: '/blog/:id',
        component: BlogPost
      },
      {
        path: '/blog/form',
        component: BlogForm
      },
    {path: "/:catchAll(.*)", component: Error404},

]

const router = createRouter({
    history: createWebHistory(),
    routes, 
})


export default router;