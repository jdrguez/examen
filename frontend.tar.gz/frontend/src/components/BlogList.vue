<template>
  <div>
    <h1>Blog Posts</h1>
    <slot name="header"></slot>
    <ul>
      <li v-for="post in posts" :key="post.id" class="post-item">
        <router-link :to="'/blog/' + post.id">{{ post.title }}</router-link>
      </li>
    </ul>
    <button @click="navigateToForm">Crea un nuevo post</button>
  </div>
</template>

<script lang="ts">
import { defineComponent } from 'vue';
import { useBlogStore } from '../stores/blogStore';
import { useRouter } from 'vue-router';

export default defineComponent({
  setup() {
    const store = useBlogStore();
    const posts = store.posts;
    const router = useRouter();
    const post_item = document.getElementsByClassName("post-item")
    const navigateToForm = () => {
      router.push('/blog/form');
    };
    return { posts, navigateToForm };
  }
});
</script>

<style scoped>
</style>
