<template>
  <div>
    <h1>{{ $t(isEdit ? 'editPost' : 'createPost') }}</h1>
    <form @submit.prevent="submitForm">
      <div>
        <label for="title">{{ $t('title') }}:</label>
        <input type="text" v-model="form.title" required />
      </div>
      <div>
        <label for="content">{{ $t('content') }}:</label>
        <textarea v-model="form.content" required></textarea>
      </div>
      <button type="submit">{{ $t(isEdit ? 'update' : 'create') }}</button>
    </form>
  </div>
</template>

<script lang="ts">
import { defineComponent, ref } from 'vue';
import { useBlogStore } from '../stores/blogStore';
import { useRoute, useRouter } from 'vue-router';

export default defineComponent({
  setup() {
    const store = useBlogStore();
    const route = useRoute();
    const router = useRouter();
    const isEdit = !!route.params.id;
    const form = ref({
      title: '',
      content: ''
    });

    const submitForm = () => {
      if (isEdit) {
        store.updatePost(route.params.id, form.value);
      } else {
        store.createPost(form.value);
      }
      router.push('/blog')
    };

    return { form, submitForm, isEdit };
  }
});
</script>

<style scoped>
</style>
