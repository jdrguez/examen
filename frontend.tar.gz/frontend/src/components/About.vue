<template>

<section class="about-section text-center text-md-start container">
    <div class="row align-items-center">
      <div class="col-md-4 mb-4 mb-md-0">
        <img src="../assets/foto.jpeg" alt="Profile Image" class="profile-img">
      </div>
      <div class="col-md-8">
        <h1>Sobre mí</h1>
        <p>
          ¡Hola! Soy <strong>José Domingo Rodríguez Rodríguez</strong>, un apasionado desarrollador web en constante aprendizaje. 
          Me encanta crear aplicaciones funcionales y visualmente atractivas, utilizando las últimas tecnologías del mercado.
        </p>
        <p>
          Mi objetivo es contribuir a proyectos innovadores y superar siempre las expectativas con soluciones eficientes y creativas.
        </p>
        <div class="icon-box">
          <i class="bi bi-lightbulb"></i>
          <span>Creativo y resolutivo</span>
        </div>
        <div class="icon-box">
          <i class="bi bi-gear"></i>
          <span>Apasionado por la tecnología</span>
        </div>
        <div class="icon-box">
          <i class="bi bi-people"></i>
          <span>Trabajo en equipo</span>
        </div>
      </div>
    </div>
  </section>


</template>

<script>
    export default {
        
    }
</script>