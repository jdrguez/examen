<template>
  <div>
    <h1 v-if="post">{{ post.title }}</h1>
    <p v-if="post">{{ post.content }}</p>
    <p v-else>Post not found.</p>
    <router-link to="/blog">Vuelve a tu blog</router-link>
  </div>
</template>

<script lang="ts">
import { defineComponent } from 'vue';
import { useBlogStore } from '../stores/blogStore';
import { useRoute } from 'vue-router';

export default defineComponent({
  setup() {
    const store = useBlogStore();
    const route = useRoute();
    const postId = parseInt(route.params.id);
    const post = store.getPostById(postId);

    return { post };
  }
});
</script>

<style scoped>
</style>
